Changelog
=========
 
## 1.1.4 (2021-03-11)
 * Update Highlight.js
 * Added destroy method
 * Added Gulp.js toolkit and change project structure
 
## 1.1.3 (2020-04-14)
 * Added label and tooltip translations
 * Added preventDefault() for dropdown links
 * Fixed path info in footer
 
## 1.1.2 (2020-03-26)
 * Added visual blocks view mode, fixed some bugs
 
## 1.1.1 (2019-05-29)
 * Bugfix
 
## 1.1.0 (2019-04-07)
 * Bugfix and refactoring
 
## 1.0.1 (2019-02-04)
 * Test release