-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 13, 2022 at 12:44 PM
-- Server version: 10.4.19-MariaDB-log
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `novel`
--

-- --------------------------------------------------------

--
-- Table structure for table `deposit`
--

CREATE TABLE `deposit` (
  `deposit_id` int(11) NOT NULL,
  `deposit_reference` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `nominal` int(11) NOT NULL,
  `metode_pembayaran` varchar(255) DEFAULT NULL,
  `kode_bayar` text DEFAULT NULL,
  `status` enum('pending','success','failed','expired','canceled','refunded') NOT NULL DEFAULT 'pending',
  `note` text DEFAULT NULL,
  `log_response_callback` text DEFAULT NULL,
  `payed_at` timestamp NULL DEFAULT NULL,
  `expired_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deposit`
--

INSERT INTO `deposit` (`deposit_id`, `deposit_reference`, `user_id`, `nominal`, `metode_pembayaran`, `kode_bayar`, `status`, `note`, `log_response_callback`, `payed_at`, `expired_at`, `created_at`, `updated_at`) VALUES
(1, 'DP0001hFUdRQZP6J', 0, 10000, '0', NULL, 'pending', 'Deposit #1 sebesar Rp.10.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 09:45:02', '2022-09-11 09:45:02', '2022-09-11 09:45:02'),
(2, 'DP0002kai1cy2FEX', 0, 10000, '0', NULL, 'pending', 'Deposit #2 sebesar Rp.10.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 11:33:37', '2022-09-11 11:33:37', '2022-09-11 11:33:37'),
(3, 'DP0003FWFfXTyG3Q', 0, 100000, '0', NULL, 'pending', 'Deposit #3 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 11:47:41', '2022-09-11 11:47:41', '2022-09-11 11:47:41'),
(4, 'DP0004lJQyca6YOy', 0, 100000, '0', NULL, 'pending', 'Deposit #4 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 11:48:08', '2022-09-11 11:48:08', '2022-09-11 11:48:08'),
(5, 'DP0005jKnTxFSlOm', 0, 100000, '0', NULL, 'pending', 'Deposit #5 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 11:48:33', '2022-09-11 11:48:33', '2022-09-11 11:48:33'),
(6, 'DP0006vKUbVFJMmZ', 0, 100000, '0', NULL, 'pending', 'Deposit #6 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 11:49:01', '2022-09-11 11:49:01', '2022-09-11 11:49:01'),
(7, 'DP0007sSQXOQavop', 0, 100000, '0', NULL, 'pending', 'Deposit #7 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 11:50:45', '2022-09-11 11:50:45', '2022-09-11 11:50:45'),
(8, 'DP0008elEGsN7AMR', 0, 100000, '0', NULL, 'pending', 'Deposit #8 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 11:52:26', '2022-09-11 11:52:26', '2022-09-11 11:52:26'),
(9, 'DP0009qRXzSpAH8U', 0, 100000, '0', NULL, 'pending', 'Deposit #9 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 11:53:05', '2022-09-11 11:53:05', '2022-09-11 11:53:05'),
(10, 'DP0010YxcKHrdAJ5', 0, 100000, '0', NULL, 'pending', 'Deposit #10 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 11:53:50', '2022-09-11 11:53:50', '2022-09-11 11:53:50'),
(11, 'DP0011WtKMUHhicK', 0, 100000, '0', NULL, 'pending', 'Deposit #11 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 11:54:57', '2022-09-11 11:54:57', '2022-09-11 11:54:57'),
(12, 'DP0012vrdOWKtvKi', 0, 100000, '0', NULL, 'pending', 'Deposit #12 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 11:57:23', '2022-09-11 11:57:23', '2022-09-11 11:57:23'),
(13, 'DP0013BnyjMx2SCJ', 0, 100000, '0', NULL, 'pending', 'Deposit #13 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 11:57:48', '2022-09-11 11:57:48', '2022-09-11 11:57:48'),
(14, 'DP000001420PHY', 4, 100000, NULL, NULL, 'pending', 'Deposit #14 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-11 21:24:33', '2022-09-11 19:24:33', '2022-09-11 19:24:33'),
(15, 'DP0000015CK1RV', 4, 100000, NULL, NULL, 'pending', 'Deposit #15 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-12 04:45:43', '2022-09-12 02:45:43', '2022-09-12 02:45:43'),
(16, 'DP00000168OC71', 4, 100000, NULL, NULL, 'pending', 'Deposit #16 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-12 04:46:31', '2022-09-12 02:46:31', '2022-09-12 02:46:31'),
(17, 'DP0000017UENAV', 4, 100000, NULL, NULL, 'pending', 'Deposit #17 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-12 04:48:59', '2022-09-12 02:48:59', '2022-09-12 02:48:59'),
(18, 'DP00000180N3QU', 4, 100000, NULL, NULL, 'pending', 'Deposit #18 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-12 04:54:08', '2022-09-12 02:54:08', '2022-09-12 02:54:08'),
(19, 'DP0000019AIBRV', 4, 100000, NULL, NULL, 'pending', 'Deposit #19 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-12 04:56:14', '2022-09-12 02:56:14', '2022-09-12 02:56:14'),
(20, 'DP0000020UVRP4', 4, 100000, NULL, NULL, 'pending', 'Deposit #20 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-12 05:00:14', '2022-09-12 03:00:14', '2022-09-12 03:00:14'),
(21, 'DP0000021DM7QZ', 4, 100000, NULL, NULL, 'pending', 'Deposit #21 sebesar Rp.100.000 Pending', NULL, '2022-09-12 08:14:43', '2022-09-12 05:06:47', '2022-09-12 03:06:47', '2022-09-12 03:06:47'),
(22, 'DP0000022GV90I', 4, 100000, NULL, NULL, 'success', 'Deposit #DP0000022GV90I', NULL, '2022-09-12 08:14:43', '2022-09-12 05:09:18', '2022-09-12 03:09:18', '2022-09-12 03:09:18'),
(23, 'DP0000023XTCP6', 4, 100000, NULL, NULL, 'success', 'Deposit #DP0000023XTCP6', NULL, '2022-09-12 08:14:43', '2022-09-12 05:26:31', '2022-09-12 03:26:31', '2022-09-12 03:26:31');

-- --------------------------------------------------------

--
-- Table structure for table `genre`
--

CREATE TABLE `genre` (
  `genre_id` int(11) NOT NULL,
  `nama_genre` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `genre`
--

INSERT INTO `genre` (`genre_id`, `nama_genre`) VALUES
(1, 'Adventure'),
(2, 'Demons'),
(3, 'Fantasy'),
(4, 'Gore'),
(5, 'Horor'),
(6, 'Magic'),
(7, 'Action'),
(8, 'Comedy'),
(9, 'Drama'),
(10, 'Game'),
(11, 'Harem'),
(12, 'Isekai'),
(13, 'Martial Arts'),
(14, 'Adult'),
(16, 'Ecchi'),
(18, 'Mature'),
(19, 'Romance');

-- --------------------------------------------------------

--
-- Table structure for table `history_login`
--

CREATE TABLE `history_login` (
  `history_login_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `info` text NOT NULL,
  `user_agent` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history_login`
--

INSERT INTO `history_login` (`history_login_id`, `user_id`, `info`, `user_agent`, `tanggal`) VALUES
(12, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 07:51:09'),
(13, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 08:05:05'),
(14, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 08:51:31'),
(15, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 08:51:41'),
(16, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 08:52:04'),
(17, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 08:52:43'),
(18, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 10:16:12'),
(19, 5, 'superadmin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 10:23:26'),
(20, 5, 'superadmin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 10:26:01'),
(21, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 10:28:45'),
(22, 5, 'superadmin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 10:32:16'),
(23, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 10:48:27'),
(24, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 11:20:19'),
(25, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 14:49:34'),
(26, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 15:13:16'),
(27, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 15:35:35'),
(28, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-11 16:09:22'),
(29, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-12 14:09:10'),
(30, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-12 14:47:12'),
(31, 8, 'supervisor Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-12 14:50:40'),
(32, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-12 14:57:58'),
(33, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-12 15:12:55'),
(34, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-12 15:17:58'),
(35, 12, '2017310023 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-12 15:37:49'),
(36, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-12 15:38:43'),
(37, 12, '2017310023 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-12 15:48:29'),
(38, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-12 15:49:11'),
(39, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-13 04:44:09'),
(40, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-13 07:36:07'),
(41, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-13 10:27:40'),
(42, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-14 08:49:02'),
(43, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-14 08:49:35'),
(44, 12, '2017310023 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-14 10:48:05'),
(45, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-14 16:48:58'),
(46, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-14 16:49:35'),
(47, 12, '2017310023 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-14 19:10:47'),
(48, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-15 01:59:48'),
(49, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-15 02:06:25'),
(50, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-15 03:09:54'),
(51, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-15 03:19:37'),
(52, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-15 03:21:46'),
(53, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-15 03:22:06'),
(54, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36', '2022-06-16 10:30:25'),
(55, 12, '2017310023 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36', '2022-06-16 10:49:09'),
(56, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36', '2022-06-16 10:54:45'),
(57, 12, '2017310023 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36', '2022-06-16 10:55:49'),
(58, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36', '2022-06-16 10:58:52'),
(59, 20, '22008960 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36', '2022-06-16 11:02:10'),
(60, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36', '2022-06-16 11:04:50'),
(61, 21, '22008961 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36', '2022-06-16 11:08:40'),
(62, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36', '2022-06-16 11:17:02'),
(63, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36', '2022-06-16 11:36:51'),
(64, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36', '2022-06-16 11:58:05'),
(65, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.115 Safari/537.36', '2022-06-18 05:45:00'),
(66, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-20 00:07:32'),
(67, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-20 02:56:26'),
(68, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-20 11:19:23'),
(69, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-20 11:28:07'),
(70, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-20 11:32:32'),
(71, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-20 11:38:36'),
(72, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-20 11:43:30'),
(73, 28, '22008990 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-20 11:52:05'),
(74, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-20 12:19:06'),
(75, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-20 12:39:31'),
(76, 28, '22008990 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-20 12:44:16'),
(77, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-20 12:51:20'),
(78, 28, '22008990 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-20 12:54:26'),
(79, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-21 09:29:06'),
(80, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-21 09:51:45'),
(81, 28, '22008990 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-21 09:52:51'),
(82, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-21 10:22:44'),
(83, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-22 09:26:42'),
(84, 29, '22008963 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-22 09:32:50'),
(85, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-22 09:36:12'),
(86, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-22 14:29:47'),
(87, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-23 01:17:47'),
(88, 28, '22008990 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-23 01:29:46'),
(89, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-23 09:42:15'),
(90, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-24 08:48:41'),
(91, 28, '22008990 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-24 12:37:27'),
(92, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-25 09:41:05'),
(93, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-25 10:12:32'),
(94, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-25 10:35:05'),
(95, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-25 11:06:32'),
(96, 28, '22008990 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-25 11:09:04'),
(97, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-25 11:25:25'),
(98, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-25 11:30:42'),
(99, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-26 10:53:23'),
(100, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-06-29 08:48:08'),
(101, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-07-01 11:15:25'),
(102, 31, '22008966 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-07-01 11:16:00'),
(103, 31, '22008966 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-07-01 11:19:38'),
(104, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-07-01 11:27:54'),
(105, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-07-01 11:28:38'),
(106, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-07-01 11:29:49'),
(107, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-07-01 12:07:36'),
(108, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-07-02 09:44:03'),
(109, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-07-02 11:08:19'),
(110, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-07-02 11:24:16'),
(111, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-07-02 11:39:24'),
(112, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', '2022-07-02 11:43:25'),
(113, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '2022-07-08 23:21:56'),
(114, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '2022-07-08 23:27:04'),
(115, 24, '22008962 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '2022-07-08 23:30:06'),
(116, 24, '22008962 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '2022-07-08 23:30:57'),
(117, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '2022-07-08 23:38:40'),
(118, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '2022-07-12 10:26:56'),
(119, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '2022-07-12 15:01:43'),
(120, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '2022-07-12 15:03:07'),
(121, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '2022-07-12 15:43:57'),
(122, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '2022-07-12 16:21:08'),
(123, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '2022-08-01 14:35:41'),
(124, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '2022-08-01 14:43:21'),
(125, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '2022-08-01 14:52:29'),
(126, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-11 14:28:36'),
(127, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-18 08:11:18'),
(128, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-18 08:13:30'),
(129, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-18 10:01:18'),
(130, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-18 10:02:06'),
(131, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-18 10:02:26'),
(132, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-18 10:38:41'),
(133, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-18 13:24:53'),
(134, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-18 14:15:48'),
(135, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-18 14:19:12'),
(136, 57, 'karyawan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-18 14:26:00'),
(137, 59, 'pimpinan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-18 14:26:35'),
(138, 58, 'keuangan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-18 14:26:56'),
(139, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 00:33:36'),
(140, 57, 'karyawan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 00:54:25'),
(141, 59, 'pimpinan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 00:58:11'),
(142, 58, 'keuangan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 01:23:04'),
(143, 57, 'karyawan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 01:24:18'),
(144, 59, 'pimpinan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 02:00:56'),
(145, 57, 'karyawan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 03:30:13'),
(146, 59, 'pimpinan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 03:30:34'),
(147, 58, 'keuangan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 03:40:02'),
(148, 59, 'pimpinan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 03:41:24'),
(149, 57, 'karyawan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 04:05:35'),
(150, 57, 'karyawan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 04:05:50'),
(151, 58, 'keuangan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 04:06:12'),
(152, 59, 'pimpinan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 04:06:32'),
(153, 57, 'karyawan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 04:14:58'),
(154, 58, 'keuangan Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 04:20:49'),
(155, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 04:36:41'),
(156, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 07:58:02'),
(157, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-19 08:24:23'),
(158, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-20 09:41:08'),
(159, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-21 14:34:19'),
(160, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-22 03:08:54'),
(161, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-22 03:09:02'),
(162, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-22 03:18:48'),
(163, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-22 03:18:59'),
(164, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-22 03:19:47'),
(165, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-27 09:51:25'),
(166, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-27 09:55:10'),
(167, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-27 10:20:19'),
(168, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-27 20:29:47'),
(169, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-28 10:22:37'),
(170, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-28 13:43:38'),
(171, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-08-29 01:59:13'),
(172, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-09-06 15:24:59'),
(173, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-09-06 15:31:25'),
(174, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-09-06 15:40:08'),
(175, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-09-06 22:13:19'),
(176, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-09-06 22:48:31'),
(177, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-09-07 04:22:53'),
(178, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '2022-09-07 06:30:30'),
(179, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-07 14:34:37'),
(180, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-07 15:20:38'),
(181, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-08 01:02:28'),
(182, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-08 10:13:53'),
(183, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-08 12:15:55'),
(184, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-09 02:20:31'),
(185, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-09 03:46:05'),
(186, 3, 'Bayu29 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-10 03:43:50'),
(187, 4, 'Bayu2903 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-10 10:32:13'),
(188, 4, 'Bayu2903 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-10 10:32:57'),
(189, 4, 'Bayu2903 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-11 06:09:14'),
(190, 4, 'Bayu2903 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-11 09:37:20'),
(191, 4, 'Bayu2903 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-11 18:18:47'),
(192, 4, 'Bayu2903 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-12 02:45:12'),
(193, 3, 'Bayu29 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-12 12:35:51'),
(194, 1, 'admin Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-12 18:46:07'),
(195, 4, 'Bayu2903 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-13 01:50:11'),
(196, 4, 'Bayu2903 Telah melakukan login', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', '2022-09-13 11:26:47');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `member_id` int(11) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `jk_kelamin` varchar(15) NOT NULL,
  `alamat` text NOT NULL,
  `saldo_akun` int(11) NOT NULL,
  `is_aktif` varchar(10) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`member_id`, `nama`, `email`, `no_hp`, `jk_kelamin`, `alamat`, `saldo_akun`, `is_aktif`, `photo`, `password`) VALUES
(15, 'Dolore fugiat harum', 'voson@mailinator.com', 'Velit nulla duis ali', 'Laki Laki', 'Dolore earum assumen', 0, 'Non Aktif', 'File-220909-33a889ff20.jpg', 'Pa$$w0rd!');

-- --------------------------------------------------------

--
-- Table structure for table `mutasi_saldo`
--

CREATE TABLE `mutasi_saldo` (
  `mutasi_saldo_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `nominal` int(11) NOT NULL DEFAULT 0,
  `saldo` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `catatan` text DEFAULT NULL,
  `type` enum('debit','credit') NOT NULL,
  `trx_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mutasi_saldo`
--

INSERT INTO `mutasi_saldo` (`mutasi_saldo_id`, `user_id`, `nominal`, `saldo`, `catatan`, `type`, `trx_id`, `created_at`, `updated_at`) VALUES
(1, 4, 100000, 100000, 'Penambahan saldo dari deposit #23', 'credit', 23, '2022-09-13 02:59:19', '2022-09-13 02:59:19'),
(3, 4, 1000, 199000, 'Pembelian Chapter 1 dari novel Novel Ayah Dan Sirkus Pohon sebesar 1000', 'debit', 10, '2022-09-13 12:18:46', '2022-09-13 12:18:46'),
(4, 4, 1000, 198000, 'Pembelian Chapter 1 dari novel Novel Ayah Dan Sirkus Pohon sebesar 1000', 'debit', 11, '2022-09-13 12:19:44', '2022-09-13 12:19:44'),
(5, 4, 1000, 197000, 'Pembelian Chapter 2 dari novel Novel Ayah Dan Sirkus Pohon sebesar 1000', 'debit', 12, '2022-09-13 12:20:13', '2022-09-13 12:20:13'),
(6, 4, 1000, 196000, 'Pembelian Chapter 1 dari novel Novel Ayah Dan Sirkus Pohon sebesar 1000', 'debit', 13, '2022-09-13 12:20:54', '2022-09-13 12:20:54'),
(7, 4, 1000, 195000, 'Pembelian Chapter 2 dari novel Novel Ayah Dan Sirkus Pohon sebesar 1000', 'debit', 14, '2022-09-13 12:21:02', '2022-09-13 12:21:02');

-- --------------------------------------------------------

--
-- Table structure for table `novel`
--

CREATE TABLE `novel` (
  `novel_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `tgl_released` date NOT NULL,
  `total_chapter` varchar(10) NOT NULL,
  `author` varchar(200) NOT NULL,
  `sinopsis` text NOT NULL,
  `rating` varchar(200) NOT NULL,
  `thumbnail` varchar(200) NOT NULL,
  `update_on` timestamp NULL DEFAULT NULL,
  `status` varchar(100) NOT NULL,
  `type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `novel`
--

INSERT INTO `novel` (`novel_id`, `title`, `tgl_released`, `total_chapter`, `author`, `sinopsis`, `rating`, `thumbnail`, `update_on`, `status`, `type_id`) VALUES
(23, 'Adipisicing velit o', '1972-10-13', 'Nulla nemo', 'Voluptatum quis et i', 'Commodi voluptate bl', '10', 'File-220909-510f67d177.jpg', NULL, 'Ongoing', 1),
(24, 'Cantik Itu Luka', '2022-09-09', '5', 'Eka Kurniawan', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '5', 'File-220909-76a5cce9be.jpg', NULL, 'Completed', 1),
(25, 'Kita Pergi Hari ini', '2022-09-09', '5', 'Ziggy Zezsyazeoviennazabrizkie', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '10', 'File-220909-e0a8625fa6.jpg', NULL, 'Ongoing', 1),
(26, 'Bersyukur Tanpa Libur', '2022-09-09', '5', 'Arswendo Atmowiloto', 'sang empu “jurus” Mengarang Itu Gampang, selalu mengasah kesaktiannya dengan menulis kapan pun, di mana pun… dengan coretan tangan, mesin tik, hingga komputer. Inilah kumpulan tulisannya mengenai memaknai hidup dengan terus bersyukur, yang berserakan tertinggal di komputernya---tentang awal kehidupannya di Solo, kehangatan keluarga yang dicintainya, kiprahnya di rimba “persilatan” media hingga penjara; dilengkapi dengan tulisan-tulisan mereka yang paling dekat, para sahabatnya dari berbagai kalangan.', '8', 'File-220909-3ec86e9cec.jpg', NULL, 'Completed', 1),
(27, 'Novel Ayah Dan Sirkus Pohon', '2022-09-09', '5', 'Andrea Hirata', 'adalah pemenang pertama penghargaan sastra New York Book Festival 2013, untuk The Rainbow Troops, Laskar Pelangi edisi Amerika, penerbit Farrar, Straus & Giroux, New York, kategori general fiction, dan pemenang pertama Buchawards 2013, Jerman, untuk Die Regenbogen Truppe, Laskar Pelangi edisi Jerman, penerbit Hanser Berlin. Dia juga p ...', '7', 'File-220909-522b804930.jpg', NULL, 'Ongoing', 1);

-- --------------------------------------------------------

--
-- Table structure for table `novel_chapter`
--

CREATE TABLE `novel_chapter` (
  `novel_chapter_id` int(11) NOT NULL,
  `novel_id` int(11) NOT NULL,
  `nama_chapter` varchar(255) DEFAULT NULL,
  `isi_chapter` text DEFAULT NULL,
  `harga` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `novel_chapter`
--

INSERT INTO `novel_chapter` (`novel_chapter_id`, `novel_id`, `nama_chapter`, `isi_chapter`, `harga`, `created_at`, `updated_at`) VALUES
(6, 23, 'Chapter 201', '<div><h2>sfdgdfgdfgdfgd</h2><h2>What is Lorem Ipsum?</h2><p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div><div><h2>Why do we use it?</h2><p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p></div><br><div><h2>Where does it come from?</h2><p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p><p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p></div><div><h2>Where can I get some?</h2><p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p></div>', 1000, '2022-09-09 04:21:32', '2022-09-09 04:22:01'),
(7, 27, 'Chapter 1', '<div><h2>What is Lorem Ipsum?</h2><p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div><div><h2>Why do we use it?</h2><p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p></div><br><div><h2>Where does it come from?</h2><p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p><p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p></div><div><h2>Where can I get some?</h2><p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p></div>', 1000, '2022-09-13 06:03:42', '2022-09-13 06:03:42'),
(8, 27, 'Chapter 2', '<div><h2>What is Lorem Ipsum?</h2><p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div><div><h2>Why do we use it?</h2><p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p></div><br><div><h2>Where does it come from?</h2><p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p><p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p></div><div><h2>Where can I get some?</h2><p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p></div>', 1000, '2022-09-13 06:04:28', '2022-09-13 06:04:28');

-- --------------------------------------------------------

--
-- Table structure for table `novel_genre`
--

CREATE TABLE `novel_genre` (
  `novel_genre_id` int(11) NOT NULL,
  `novel_id` int(11) NOT NULL,
  `genre_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `novel_genre`
--

INSERT INTO `novel_genre` (`novel_genre_id`, `novel_id`, `genre_id`) VALUES
(106, 23, 19),
(107, 23, 18),
(108, 23, 12),
(109, 23, 11),
(110, 23, 10),
(111, 23, 9),
(112, 23, 6),
(113, 23, 4),
(114, 24, 19),
(115, 24, 9),
(116, 25, 19),
(117, 25, 9),
(118, 25, 1),
(119, 26, 9),
(120, 27, 19);

-- --------------------------------------------------------

--
-- Table structure for table `pembelian_chapter`
--

CREATE TABLE `pembelian_chapter` (
  `pembelian_chapter_id` int(11) NOT NULL,
  `kode_pembelian` varchar(100) DEFAULT NULL,
  `member_id` int(11) NOT NULL,
  `novel_chapter_id` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `tanggal_pembelian` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelian_chapter`
--

INSERT INTO `pembelian_chapter` (`pembelian_chapter_id`, `kode_pembelian`, `member_id`, `novel_chapter_id`, `harga`, `tanggal_pembelian`) VALUES
(13, 'CPR0000013AARIQ', 4, 7, 1000, '2022-09-13 00:00:00'),
(14, 'CPR0000014VGC25', 4, 8, 1000, '2022-09-13 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `setting_web`
--

CREATE TABLE `setting_web` (
  `setting_web_id` int(11) NOT NULL,
  `nama_website` varchar(200) NOT NULL,
  `logo` varchar(200) NOT NULL,
  `telpon` varchar(20) NOT NULL,
  `email` varchar(150) NOT NULL,
  `email_password` varchar(255) DEFAULT NULL,
  `deskripsi` text NOT NULL,
  `is_aktif_website` varchar(20) NOT NULL,
  `id_merchant_midtrans` text DEFAULT NULL,
  `client_key_midtrans` text DEFAULT NULL,
  `server_key_midtrans` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setting_web`
--

INSERT INTO `setting_web` (`setting_web_id`, `nama_website`, `logo`, `telpon`, `email`, `email_password`, `deskripsi`, `is_aktif_website`, `id_merchant_midtrans`, `client_key_midtrans`, `server_key_midtrans`) VALUES
(1, 'Baca Novel', 'File-220907-cc6dc50dff.png', '083874731480', 'bayusegara623@gmail.com', 'mrvybghhgdqmxmfu', 'Website baca novel', 'Aktif', 'G365173382', 'SB-Mid-client-iN0YJC2kMSOPSgYB', 'SB-Mid-server-Nc_qDOyxG0vHEImcE8mAXWpK');

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

CREATE TABLE `token` (
  `token_id` int(11) NOT NULL,
  `token` text DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `token`
--

INSERT INTO `token` (`token_id`, `token`, `user_id`, `created_at`, `updated_at`) VALUES
(1, '99d4ccdd45b3e6e64d3bd31149aaf2', 3, '2022-09-12 12:32:59', '2022-09-12 10:32:59'),
(2, '4d92e6a7e504697714683fafd71ede', 3, '2022-09-12 13:29:43', '2022-09-12 11:29:43'),
(3, 'ac795f084e2d64a741683096f8f3cd', 3, '2022-09-12 13:30:46', '2022-09-12 11:30:46'),
(4, '14791eb542ed7fceedcba6603946f2', 3, '2022-09-12 13:36:38', '2022-09-12 11:36:38'),
(5, 'f24c524c05f1a5de04b87136aa7cd1', 3, '2022-09-12 13:42:12', '2022-09-12 11:42:12'),
(6, '31bd19d3d495a23b8f0a8a1460ced2', 3, '2022-09-12 14:28:01', '2022-09-12 12:28:01');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `type_id` int(11) NOT NULL,
  `nama_type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`type_id`, `nama_type`) VALUES
(1, 'Original'),
(2, 'Terjemahan Bahasa');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `nama_lengkap` varchar(200) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `level_id` int(2) NOT NULL COMMENT '1:admin,2:user',
  `saldo` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `nama_lengkap`, `email`, `username`, `password`, `no_hp`, `level_id`, `saldo`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', NULL, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', '083874731480', 1, 0, '2022-09-10 04:24:22', '2022-09-10 04:24:22'),
(3, 'Bayu Segara', 'bayusegara623@gmail.com', 'Bayu29', '7c222fb2927d828af22f592134e8932480637c0d', '08987499383', 2, 0, '2022-09-10 04:24:22', '2022-09-10 04:24:22'),
(4, 'Bayu segara', 'bsegara2903@gmail.com', 'Bayu2903', '7c222fb2927d828af22f592134e8932480637c0d', '082131445043', 2, 195000, '2022-09-10 10:32:13', '2022-09-10 10:32:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `deposit`
--
ALTER TABLE `deposit`
  ADD PRIMARY KEY (`deposit_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`genre_id`);

--
-- Indexes for table `history_login`
--
ALTER TABLE `history_login`
  ADD PRIMARY KEY (`history_login_id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `mutasi_saldo`
--
ALTER TABLE `mutasi_saldo`
  ADD PRIMARY KEY (`mutasi_saldo_id`),
  ADD KEY `user_id` (`user_id`) USING BTREE;

--
-- Indexes for table `novel`
--
ALTER TABLE `novel`
  ADD PRIMARY KEY (`novel_id`),
  ADD KEY `type_id` (`type_id`);

--
-- Indexes for table `novel_chapter`
--
ALTER TABLE `novel_chapter`
  ADD PRIMARY KEY (`novel_chapter_id`),
  ADD KEY `novel_id` (`novel_id`);

--
-- Indexes for table `novel_genre`
--
ALTER TABLE `novel_genre`
  ADD PRIMARY KEY (`novel_genre_id`),
  ADD KEY `novel_id` (`novel_id`),
  ADD KEY `novel_genre_ibfk_2` (`genre_id`);

--
-- Indexes for table `pembelian_chapter`
--
ALTER TABLE `pembelian_chapter`
  ADD PRIMARY KEY (`pembelian_chapter_id`),
  ADD KEY `novel_chapter_id` (`novel_chapter_id`),
  ADD KEY `member` (`member_id`) USING BTREE;

--
-- Indexes for table `setting_web`
--
ALTER TABLE `setting_web`
  ADD PRIMARY KEY (`setting_web_id`);

--
-- Indexes for table `token`
--
ALTER TABLE `token`
  ADD PRIMARY KEY (`token_id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `deposit`
--
ALTER TABLE `deposit`
  MODIFY `deposit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `genre`
--
ALTER TABLE `genre`
  MODIFY `genre_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `history_login`
--
ALTER TABLE `history_login`
  MODIFY `history_login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=197;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `mutasi_saldo`
--
ALTER TABLE `mutasi_saldo`
  MODIFY `mutasi_saldo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `novel`
--
ALTER TABLE `novel`
  MODIFY `novel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `novel_chapter`
--
ALTER TABLE `novel_chapter`
  MODIFY `novel_chapter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `novel_genre`
--
ALTER TABLE `novel_genre`
  MODIFY `novel_genre_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `pembelian_chapter`
--
ALTER TABLE `pembelian_chapter`
  MODIFY `pembelian_chapter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `setting_web`
--
ALTER TABLE `setting_web`
  MODIFY `setting_web_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `token`
--
ALTER TABLE `token`
  MODIFY `token_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `novel`
--
ALTER TABLE `novel`
  ADD CONSTRAINT `novel_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `type` (`type_id`);

--
-- Constraints for table `novel_chapter`
--
ALTER TABLE `novel_chapter`
  ADD CONSTRAINT `novel_chapter_ibfk_1` FOREIGN KEY (`novel_id`) REFERENCES `novel` (`novel_id`) ON DELETE CASCADE;

--
-- Constraints for table `novel_genre`
--
ALTER TABLE `novel_genre`
  ADD CONSTRAINT `novel_genre_ibfk_1` FOREIGN KEY (`novel_id`) REFERENCES `novel` (`novel_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `novel_genre_ibfk_2` FOREIGN KEY (`genre_id`) REFERENCES `genre` (`genre_id`) ON DELETE CASCADE;

--
-- Constraints for table `pembelian_chapter`
--
ALTER TABLE `pembelian_chapter`
  ADD CONSTRAINT `pembelian_chapter_ibfk_2` FOREIGN KEY (`novel_chapter_id`) REFERENCES `novel_chapter` (`novel_chapter_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
